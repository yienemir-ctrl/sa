@echo off
setlocal EnableDelayedExpansion
title cs2_external setup — built by 45ms

:: ═══════════════════════════════════════════════════════════
::  cs2_external | setup.bat
::  full scaffold: deps, imgui, cmake configure, build, refresher
::  built by 45ms — https://dsc.gg/pyre-lua
:: ═══════════════════════════════════════════════════════════

set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "VENDOR=%ROOT%\vendor"
set "IMGUI=%VENDOR%\imgui"
set "BUILD=%ROOT%\build"
set "SRC=%ROOT%\src"

echo.
echo  cs2_external setup
echo  built by 45ms ^| https://dsc.gg/pyre-lua
echo  ────────────────────────────────────────
echo.

:: ── dependency checks ───────────────────────────────────────
echo [1/5] checking dependencies...

where git    >nul 2>&1 || (echo  [FAIL] git not found   — install from https://git-scm.com & goto :err)
where cmake  >nul 2>&1 || (echo  [FAIL] cmake not found — install from https://cmake.org   & goto :err)
where python >nul 2>&1 || (echo  [FAIL] python not found — install from https://python.org & goto :err)
where cl     >nul 2>&1 || (
    echo  [FAIL] MSVC cl.exe not found
    echo         run this bat from a Visual Studio Developer Command Prompt
    echo         or run:  "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    goto :err
)
echo  [OK] git, cmake, python, MSVC found
echo.

:: ── directory scaffold ──────────────────────────────────────
echo [2/5] scaffolding directories...

for %%D in ("%VENDOR%" "%BUILD%" "%SRC%") do (
    if not exist "%%~D" (
        mkdir "%%~D"
        echo  [mkdir] %%~D
    )
)
echo  [OK] directories ready
echo.

:: ── imgui clone / update ────────────────────────────────────
echo [3/5] imgui...

if not exist "%IMGUI%\.git" (
    echo  cloning imgui docking branch...
    git clone --depth=1 --branch docking ^
        https://github.com/ocornut/imgui.git ^
        "%IMGUI%"
    if !errorlevel! neq 0 (echo  [FAIL] imgui clone failed & goto :err)
    echo  [OK] imgui cloned
) else (
    echo  imgui exists — pulling latest...
    pushd "%IMGUI%"
    git pull --ff-only
    popd
    echo  [OK] imgui up to date
)
echo.

:: ── cmake configure ─────────────────────────────────────────
echo [4/5] cmake configure...

cmake -S "%ROOT%" -B "%BUILD%" ^
    -G "Visual Studio 17 2022" -A x64 ^
    -DCMAKE_BUILD_TYPE=Release

if !errorlevel! neq 0 (echo  [FAIL] cmake configure failed & goto :err)
echo  [OK] cmake configured
echo.

:: ── build ───────────────────────────────────────────────────
echo [5/5] building Release...

cmake --build "%BUILD%" --config Release --parallel

if !errorlevel! neq 0 (echo  [FAIL] build failed & goto :err)
echo.
echo  [OK] build complete
echo  bin: %BUILD%\Release\cs2_external.exe
echo.

:: ── launch offset refresher in background ───────────────────
echo  launching offset refresher (background)...

set "REFRESHER=%ROOT%\offset_refresh.py"
if exist "%REFRESHER%" (
    start "cs2 offset refresher" /min ^
        cmd /c "python \"%REFRESHER%\" & pause"
    echo  [OK] refresher running in background window
) else (
    echo  [WARN] offset_refresh.py not found at root — skipping refresher
)

echo.
echo  ────────────────────────────────────────
echo  setup done — bench clear
echo  built by 45ms ^| https://dsc.gg/pyre-lua
echo  ────────────────────────────────────────
echo.
pause
goto :eof

:: ── error handler ────────────────────────────────────────────
:err
echo.
echo  setup failed — fix the error above and re-run
echo.
pause
exit /b 1