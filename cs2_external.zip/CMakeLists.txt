cmake_minimum_required(VERSION 3.20)
project(cs2_external CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_compile_definitions(_USE_MATH_DEFINES NOMINMAX)

set(IMGUI_DIR ${CMAKE_SOURCE_DIR}/vendor/imgui)
set(IMGUI_SOURCES
    ${IMGUI_DIR}/imgui.cpp
    ${IMGUI_DIR}/imgui_draw.cpp
    ${IMGUI_DIR}/imgui_tables.cpp
    ${IMGUI_DIR}/imgui_widgets.cpp
    ${IMGUI_DIR}/backends/imgui_impl_win32.cpp
    ${IMGUI_DIR}/backends/imgui_impl_dx11.cpp
)

add_executable(cs2_external WIN32
    src/main.cpp
    src/overlay.cpp
    src/menu.cpp
    src/esp.cpp
    src/aimbot.cpp
    ${IMGUI_SOURCES}
)

target_include_directories(cs2_external PRIVATE
    src
    ${IMGUI_DIR}
    ${IMGUI_DIR}/backends
)

target_compile_options(cs2_external PRIVATE /W4 /permissive-)
target_compile_definitions(cs2_external PRIVATE
    _USE_MATH_DEFINES
    NOMINMAX
    UNICODE
    _UNICODE
)
target_link_libraries(cs2_external PRIVATE d3d11 dxgi dinput8 dxguid)
