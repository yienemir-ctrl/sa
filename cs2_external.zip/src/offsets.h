// cs2_external | offsets.h
// PLACEHOLDER — run offset_refresh.py to overwrite with live values
// built by 45ms — https://dsc.gg/pyre-lua
#pragma once
#include <cstdint>

namespace offsets {
    // ── auto-dumped (approximate — refresher overwrites these) ───────
    inline constexpr uintptr_t dwEntityList                = 0x18B3BB8;
    inline constexpr uintptr_t dwLocalPlayerPawn           = 0x173A314;
    inline constexpr uintptr_t dwViewMatrix                = 0x19213C0;
    inline constexpr uintptr_t dwLocalPlayerController     = 0x1739F78;

    inline constexpr uintptr_t m_iHealth                   = 0x344;
    inline constexpr uintptr_t m_iTeamNum                  = 0x3CB;
    inline constexpr uintptr_t m_vOldOrigin                = 0x1294;
    inline constexpr uintptr_t m_pGameSceneNode            = 0x328;
    inline constexpr uintptr_t m_modelState                = 0x160;
    inline constexpr uintptr_t m_bDormant                  = 0x18D;
    inline constexpr uintptr_t m_iIDEntIndex               = 0x6EC;
    inline constexpr uintptr_t m_iszPlayerName             = 0x6B8;
    inline constexpr uintptr_t m_flFlashDuration           = 0x1218;
    inline constexpr uintptr_t m_pClippingWeapon           = 0xE98;
    inline constexpr uintptr_t m_iClip1                    = 0x46C;

    // ── static (verify on ABI break) ────────────────────────────────
    inline constexpr uintptr_t m_nBoneCount                = 0x1E8;
    inline constexpr uintptr_t m_pBoneArray                = 0x1F0;
    inline constexpr uintptr_t m_angEyeAngles              = 0x1510;
} // namespace offsets

namespace bones {
    inline constexpr int pelvis                            = 0;
    inline constexpr int chest                             = 4;
    inline constexpr int neck                              = 5;
    inline constexpr int head                              = 6;
} // namespace bones