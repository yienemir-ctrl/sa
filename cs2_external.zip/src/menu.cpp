// cs2_external | menu.cpp
#include "menu.h"
#include <imgui.h>
#include <Windows.h>

Config g_cfg{};

static const char* boneNames[] = { "Pelvis","Spine1","Spine2","Spine3","Chest","Neck","Head" };

namespace menu {
void draw(bool& open) {
    if (!open) return;
    ImGui::SetNextWindowSize({420, 520}, ImGuiCond_Once);
    ImGui::SetNextWindowBgAlpha(0.88f);
    ImGui::Begin("cs2 external  |  absolute 45ms", &open,
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar);

    if (ImGui::BeginTabBar("##tabs")) {

        // ── ESP ────────────────────────────────────────
        if (ImGui::BeginTabItem("ESP")) {
            bool b;
            b = g_cfg.espEnabled.load(); if (ImGui::Checkbox("Enable ESP", &b)) g_cfg.espEnabled.store(b);
            ImGui::Separator();
            ImGui::BeginDisabled(!g_cfg.espEnabled.load());
            b = g_cfg.espBox.load();      if (ImGui::Checkbox("Box",        &b)) g_cfg.espBox.store(b);
            b = g_cfg.espName.load();     if (ImGui::Checkbox("Name",       &b)) g_cfg.espName.store(b);
            b = g_cfg.espHealth.load();   if (ImGui::Checkbox("Health bar", &b)) g_cfg.espHealth.store(b);
            b = g_cfg.espDistance.load(); if (ImGui::Checkbox("Distance",   &b)) g_cfg.espDistance.store(b);
            b = g_cfg.espSnaplines.load();if (ImGui::Checkbox("Snaplines",  &b)) g_cfg.espSnaplines.store(b);
            b = g_cfg.espSkeletons.load();if (ImGui::Checkbox("Skeleton",   &b)) g_cfg.espSkeletons.store(b);
            b = g_cfg.espFlash.load();    if (ImGui::Checkbox("Hide when flashed",&b)) g_cfg.espFlash.store(b);
            int d = g_cfg.espMaxDist.load();
            if (ImGui::SliderInt("Max distance", &d, 100, 8000)) g_cfg.espMaxDist.store(d);
            ImGui::EndDisabled();
            ImGui::EndTabItem();
        }

        // ── Aimbot ─────────────────────────────────────
        if (ImGui::BeginTabItem("Aimbot")) {
            bool b;
            b = g_cfg.aimbotEnabled.load(); if (ImGui::Checkbox("Enable aimbot",&b)) g_cfg.aimbotEnabled.store(b);
            ImGui::Separator();
            ImGui::BeginDisabled(!g_cfg.aimbotEnabled.load());
            b = g_cfg.aimbotOnKey.load();    if (ImGui::Checkbox("Hold key to aim",&b)) g_cfg.aimbotOnKey.store(b);
            ImGui::Text("Aim key: RMB (hardcoded, change in config)");
            int bone = g_cfg.aimbotBone.load();
            if (ImGui::Combo("Target bone", &bone, boneNames, 7)) g_cfg.aimbotBone.store(bone);
            float sm = g_cfg.aimbotSmooth.load();
            if (ImGui::SliderFloat("Smooth", &sm, 0.01f, 1.f, "%.3f")) g_cfg.aimbotSmooth.store(sm);
            float fov = g_cfg.aimbotFOV.load();
            if (ImGui::SliderFloat("FOV", &fov, 0.5f, 45.f, "%.1f deg")) g_cfg.aimbotFOV.store(fov);
            b = g_cfg.aimbotTeamCheck.load(); if (ImGui::Checkbox("Team check",&b)) g_cfg.aimbotTeamCheck.store(b);
            b = g_cfg.aimbotFlashCheck.load();if (ImGui::Checkbox("Skip if flashed",&b)) g_cfg.aimbotFlashCheck.store(b);
            ImGui::EndDisabled();
            ImGui::EndTabItem();
        }

        // ── Misc ───────────────────────────────────────
        if (ImGui::BeginTabItem("Misc")) {
            bool b;
            b = g_cfg.noFlash.load();    if (ImGui::Checkbox("No flash",    &b)) g_cfg.noFlash.store(b);
            b = g_cfg.radarDots.load();  if (ImGui::Checkbox("Radar dots",  &b)) g_cfg.radarDots.store(b);
            ImGui::Separator();
            ImGui::TextDisabled("built by 45ms — dsc.gg/pyre-lua");
            ImGui::EndTabItem();
        }

        ImGui::EndTabBar();
    }
    ImGui::End();
}
} // namespace menu