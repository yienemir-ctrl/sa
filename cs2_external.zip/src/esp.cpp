// cs2_external | esp.cpp | box, name, health, distance, snapline, skeleton
#define NOMINMAX
#include <Windows.h>
#include "esp.h"
#include "cs2_math.h"
#include "menu.h"
#include <imgui.h>
#include <cstdio>
#include <cmath>

static ImU32 healthColor(int hp) {
    float t = hp / 100.f;
    int   r = static_cast<int>((1.f - t) * 255);
    int   g = static_cast<int>(t * 255);
    return IM_COL32(r, g, 0, 255);
}

void esp::draw(ImDrawList* dl, const std::vector<Entity>& ents,
               const Entity& local, const Mat4& vm,
               float W, float H) {
    if (!g_cfg.espEnabled.load()) return;

    int   maxDist  = g_cfg.espMaxDist.load();
    bool  doBox    = g_cfg.espBox.load();
    bool  doName   = g_cfg.espName.load();
    bool  doHp     = g_cfg.espHealth.load();
    bool  doDist   = g_cfg.espDistance.load();
    bool  doSnap   = g_cfg.espSnaplines.load();
    bool  flashHide= g_cfg.espFlash.load();

    for (const auto& e : ents) {
        if (!e.valid) continue;
        if (e.team == local.team) continue;
        if (flashHide && e.flashAlpha > 0.5f) continue;

        float dist = math::dist3D(local.origin, e.origin);
        if (dist > static_cast<float>(maxDist)) continue;

        Vec2 feet2D{}, head2D{};
        if (!math::worldToScreen(e.origin,   feet2D, vm, W, H)) continue;
        if (!math::worldToScreen(e.headPos,  head2D, vm, W, H)) continue;

        float height = feet2D.y - head2D.y;
        if (height < 2.f) continue;
        float width  = height * 0.45f;

        // ── box ───────────────────────────────────────
        if (doBox) {
            float x = head2D.x - width * 0.5f;
            float y = head2D.y;
            dl->AddRect(ImVec2{x, y}, ImVec2{x+width, y+height},
                        IM_COL32(255,255,255,210), 0.f, 0, 1.4f);
            dl->AddRect(ImVec2{x-1.f, y-1.f}, ImVec2{x+width+1.f, y+height+1.f},
                        IM_COL32(0,0,0,160), 0.f, 0, 1.f);
        }

        // ── health bar ────────────────────────────────
        if (doHp) {
            float x    = head2D.x - width * 0.5f - 6.f;
            float y    = head2D.y;
            float barH = height * (e.health / 100.f);
            dl->AddRectFilled(ImVec2{x, y+height-barH}, ImVec2{x+3.f, y+height},
                              healthColor(e.health));
            dl->AddRect(ImVec2{x, y}, ImVec2{x+3.f, y+height},
                        IM_COL32(0,0,0,180));
        }

        // ── name ──────────────────────────────────────
        if (doName && e.name[0]) {
            dl->AddText(ImVec2{head2D.x - ImGui::CalcTextSize(e.name).x * 0.5f,
                               head2D.y - 14.f},
                        IM_COL32(255,255,255,230), e.name);
        }

        // ── distance ──────────────────────────────────
        if (doDist) {
            char buf[32];
            std::snprintf(buf, sizeof(buf), "%.0fm", dist * 0.0254f);
            dl->AddText(ImVec2{feet2D.x - ImGui::CalcTextSize(buf).x * 0.5f,
                               feet2D.y + 2.f},
                        IM_COL32(200,200,200,200), buf);
        }

        // ── snapline ──────────────────────────────────
        if (doSnap)
            dl->AddLine(ImVec2{W * 0.5f, H},
                        ImVec2{feet2D.x, feet2D.y},
                        IM_COL32(255,255,0,120), 1.f);
    }
}
