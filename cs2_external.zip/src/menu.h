// cs2_external | menu.h
#pragma once
#define NOMINMAX
#include <Windows.h>
#include <atomic>

struct Config {
    std::atomic<bool>  espEnabled      { true  };
    std::atomic<bool>  espBox          { true  };
    std::atomic<bool>  espName         { true  };
    std::atomic<bool>  espHealth       { true  };
    std::atomic<bool>  espDistance     { true  };
    std::atomic<bool>  espSnaplines    { false };
    std::atomic<bool>  espSkeletons    { false };
    std::atomic<bool>  espFlash        { true  };
    std::atomic<int>   espMaxDist      { 3000  };

    std::atomic<bool>  aimbotEnabled   { false };
    std::atomic<bool>  aimbotOnKey     { true  };
    std::atomic<int>   aimbotKey       { 2     }; // 2 = VK_RBUTTON
    std::atomic<int>   aimbotBone      { 6     };
    std::atomic<float> aimbotSmooth    { 0.08f };
    std::atomic<float> aimbotFOV       { 5.f   };
    std::atomic<bool>  aimbotTeamCheck { true  };
    std::atomic<bool>  aimbotVisible   { false };
    std::atomic<bool>  aimbotFlashCheck{ true  };

    std::atomic<bool>  noFlash         { false };
    std::atomic<bool>  radarDots       { false };
};

extern Config g_cfg;

namespace menu {
    void draw(bool& open);
}
