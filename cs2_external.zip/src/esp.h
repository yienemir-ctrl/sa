// cs2_external | esp.h
#pragma once
#include "entity.h"
#include "cs2_math.h"
#include <imgui.h>
#include <vector>

namespace esp {
    void draw(ImDrawList* dl, const std::vector<Entity>& ents,
              const Entity& local, const Mat4& vm,
              float W, float H);
}
