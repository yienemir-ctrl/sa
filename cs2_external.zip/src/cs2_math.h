// cs2_external | cs2_math.h | W2S, angle calc, smooth lerp
#pragma once
#include <DirectXMath.h>
#include <array>
#include <cmath>

using Vec3 = DirectX::XMFLOAT3;
using Vec2 = DirectX::XMFLOAT2;
using Mat4 = std::array<std::array<float, 4>, 4>;

namespace math {

    inline bool worldToScreen(const Vec3& pos, Vec2& out,
                              const Mat4& vm, float W, float H) {
        float x = vm[0][0]*pos.x + vm[0][1]*pos.y + vm[0][2]*pos.z + vm[0][3];
        float y = vm[1][0]*pos.x + vm[1][1]*pos.y + vm[1][2]*pos.z + vm[1][3];
        float w = vm[3][0]*pos.x + vm[3][1]*pos.y + vm[3][2]*pos.z + vm[3][3];
        if (w < 0.001f) return false;
        float invW = 1.f / w;
        out.x = (W * 0.5f) + (x * invW) * (W * 0.5f);
        out.y = (H * 0.5f) - (y * invW) * (H * 0.5f);
        return true;
    }

    inline float dist3D(const Vec3& a, const Vec3& b) {
        float dx = a.x-b.x, dy = a.y-b.y, dz = a.z-b.z;
        return std::sqrt(dx*dx + dy*dy + dz*dz);
    }

    // calc angle from local eye to target, returns pitch/yaw delta
    inline Vec2 calcAngle(const Vec3& src, const Vec3& dst) {
        float dx = dst.x - src.x;
        float dy = dst.y - src.y;
        float dz = dst.z - src.z;
        float dist2D = std::sqrt(dx*dx + dy*dy);
        Vec2 ang;
        ang.x = -std::atan2f(dz, dist2D) * (180.f / DirectX::XM_PI); // pitch
        ang.y =  std::atan2f(dy, dx)      * (180.f / DirectX::XM_PI); // yaw
        return ang;
    }

    inline float lerp(float a, float b, float t) { return a + (b - a) * t; }

    inline Vec2 smoothAngle(const Vec2& cur, const Vec2& tgt, float smooth) {
        return { lerp(cur.x, tgt.x, smooth), lerp(cur.y, tgt.y, smooth) };
    }

    inline float fovDelta(const Vec2& cur, const Vec2& tgt) {
        float dp = tgt.x - cur.x, dy = tgt.y - cur.y;
        return std::sqrt(dp*dp + dy*dy);
    }
}
