// cs2_external | overlay.h | DX11 transparent arena overlay
#pragma once
#include <Windows.h>
#include <d3d11.h>
#include <string>
#include <functional>

class Overlay {
public:
    HWND                        hwnd    = nullptr;
    ID3D11Device*               device  = nullptr;
    ID3D11DeviceContext*        ctx     = nullptr;
    IDXGISwapChain*             swap    = nullptr;
    ID3D11RenderTargetView*     rtv     = nullptr;
    int W = 0, H = 0;

    bool init(const wchar_t* targetTitle);
    void beginFrame();
    void endFrame();
    void shutdown();
    bool alive() const;

    // ImGui frame already begun inside beginFrame
    bool shouldClose = false;

private:
    HWND targetHwnd = nullptr;
    void syncToTarget();
};