// cs2_external | entity.h | entity + bone read, fully guarded
#pragma once
#include "mem.h"
#include "offsets.h"
#include <DirectXMath.h>
#include <array>
#include <string>

using Vec3 = DirectX::XMFLOAT3;
using Vec2 = DirectX::XMFLOAT2;

struct BonePos {
    float x, y, z, w;
};

struct Entity {
    uintptr_t  pawn       = 0;
    int        health     = 0;
    int        team       = 0;
    bool       dormant    = false;
    Vec3       origin     {};
    Vec3       headPos    {};
    char       name[65]   {};
    int        ammo       = 0;
    float      flashAlpha = 0.f;
    bool       valid      = false;

    static Entity from(const Memory& mem, uintptr_t listEntry, int idx) {
        Entity e{};
        uintptr_t controller = mem.read<uintptr_t>(listEntry + 0x78 * (idx & 0x1FF));
        if (!controller) return e;
        uintptr_t pawnHandle = mem.read<uintptr_t>(controller + offsets::m_iIDEntIndex);
        uintptr_t listEntry2 = mem.read<uintptr_t>(
            mem.read<uintptr_t>(mem.base + offsets::dwEntityList) + 0x8 * ((pawnHandle & 0x7FFF) >> 9) + 0x10);
        if (!listEntry2) return e;
        e.pawn = mem.read<uintptr_t>(listEntry2 + 0x78 * (pawnHandle & 0x1FF));
        if (!e.pawn) return e;

        e.health    = mem.read<int>  (e.pawn + offsets::m_iHealth);
        e.team      = mem.read<int>  (e.pawn + offsets::m_iTeamNum);
        e.dormant   = mem.read<bool> (e.pawn + offsets::m_bDormant);
        e.origin    = mem.read<Vec3> (e.pawn + offsets::m_vOldOrigin);
        e.flashAlpha= mem.read<float>(e.pawn + offsets::m_flFlashDuration);

        mem.readBuf(controller + offsets::m_iszPlayerName, e.name, 64);
        e.name[64] = '\0';

        e.headPos   = readBone(mem, e.pawn, bones::head);
        e.valid     = e.health > 0 && e.health <= 100 && !e.dormant;
        return e;
    }

    static Vec3 readBone(const Memory& mem, uintptr_t pawn, int bone) {
        uintptr_t sceneNode = mem.read<uintptr_t>(pawn + offsets::m_pGameSceneNode);
        if (!sceneNode) return {};
        uintptr_t boneArr   = mem.read<uintptr_t>(sceneNode + offsets::m_modelState + offsets::m_pBoneArray);
        if (!boneArr) return {};
        BonePos bp = mem.read<BonePos>(boneArr + bone * sizeof(BonePos));
        return { bp.x, bp.y, bp.z };
    }
};