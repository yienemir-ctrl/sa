// cs2_external | aimbot.h
#pragma once
#include "entity.h"
#include "mem.h"
#include <vector>

namespace aimbot {
    void update(const Memory& mem,
                uintptr_t localPawn, int localTeam,
                const std::vector<Entity>& ents);
}
