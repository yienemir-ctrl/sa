// cs2_external | mem.h | windows RPM/WPM layer, read-only default
#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <stdexcept>

class Memory {
public:
    HANDLE      proc   = nullptr;
    uintptr_t   base   = 0;

    explicit Memory(const wchar_t* procName) {
        DWORD pid = getPID(procName);
        if (!pid) throw std::runtime_error("process not found");
        proc = OpenProcess(PROCESS_VM_READ, FALSE, pid);
        if (!proc || proc == INVALID_HANDLE_VALUE)
            throw std::runtime_error("OpenProcess failed");
        base = getModuleBase(pid, L"client.dll");
        if (!base) throw std::runtime_error("client.dll base not found");
    }

    ~Memory() { if (proc && proc != INVALID_HANDLE_VALUE) CloseHandle(proc); }

    template<typename T>
    T read(uintptr_t addr) const noexcept {
        T val{};
        ReadProcessMemory(proc, reinterpret_cast<LPCVOID>(addr), &val, sizeof(T), nullptr);
        return val;
    }

    bool readBuf(uintptr_t addr, void* buf, size_t sz) const noexcept {
        SIZE_T got = 0;
        return ReadProcessMemory(proc, reinterpret_cast<LPCVOID>(addr),
                                 buf, sz, &got) && got == sz;
    }

    std::string readStr(uintptr_t addr, size_t maxLen = 64) const noexcept {
        char buf[128]{};
        maxLen = maxLen < sizeof(buf) ? maxLen : sizeof(buf) - 1;
        ReadProcessMemory(proc, reinterpret_cast<LPCVOID>(addr), buf, maxLen, nullptr);
        buf[maxLen] = '\0';
        return std::string(buf);
    }

private:
    static DWORD getPID(const wchar_t* name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return 0;
        PROCESSENTRY32W pe{ sizeof(pe) };
        DWORD pid = 0;
        if (Process32FirstW(snap, &pe))
            do { if (!_wcsicmp(pe.szExeFile, name)) { pid = pe.th32ProcessID; break; } }
            while (Process32NextW(snap, &pe));
        CloseHandle(snap);
        return pid;
    }

    static uintptr_t getModuleBase(DWORD pid, const wchar_t* modName) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
        if (snap == INVALID_HANDLE_VALUE) return 0;
        MODULEENTRY32W me{ sizeof(me) };
        uintptr_t base = 0;
        if (Module32FirstW(snap, &me))
            do { if (!_wcsicmp(me.szModule, modName)) { base = reinterpret_cast<uintptr_t>(me.modBaseAddr); break; } }
            while (Module32NextW(snap, &me));
        CloseHandle(snap);
        return base;
    }
};