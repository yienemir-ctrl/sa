// cs2_external | overlay.cpp
#include "overlay.h"
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <stdexcept>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

static LRESULT CALLBACK wndProc(HWND hw, UINT msg, WPARAM wp, LPARAM lp) {
    if (ImGui_ImplWin32_WndProcHandler(hw, msg, wp, lp)) return true;
    if (msg == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(hw, msg, wp, lp);
}

bool Overlay::init(const wchar_t* targetTitle) {
    targetHwnd = FindWindowW(nullptr, targetTitle);
    if (!targetHwnd) return false;

    RECT r{};
    GetClientRect(targetHwnd, &r);
    ClientToScreen(targetHwnd, reinterpret_cast<POINT*>(&r));
    W = r.right - r.left; H = r.bottom - r.top;

    WNDCLASSEXW wc{ sizeof(wc) };
    wc.lpfnWndProc   = wndProc;
    wc.hInstance     = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"cs2_ext_overlay";
    RegisterClassExW(&wc);

    hwnd = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE,
        L"cs2_ext_overlay", L"",
        WS_POPUP, r.left, r.top, W, H,
        nullptr, nullptr, wc.hInstance, nullptr);

    SetLayeredWindowAttributes(hwnd, RGB(0,0,0), 0, LWA_COLORKEY);
    ShowWindow(hwnd, SW_SHOW);

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount        = 2;
    sd.BufferDesc.Width   = W;
    sd.BufferDesc.Height  = H;
    sd.BufferDesc.Format  = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate = { 165, 1 };
    sd.BufferUsage        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow       = hwnd;
    sd.SampleDesc.Count   = 1;
    sd.Windowed           = TRUE;
    sd.SwapEffect         = DXGI_SWAP_EFFECT_FLIP_DISCARD;

    D3D_FEATURE_LEVEL fl;
    if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE,
        nullptr, 0, nullptr, 0, D3D11_SDK_VERSION,
        &sd, &swap, &device, &fl, &ctx)))
        return false;

    ID3D11Texture2D* bb = nullptr;
    swap->GetBuffer(0, IID_PPV_ARGS(&bb));
    device->CreateRenderTargetView(bb, nullptr, &rtv);
    bb->Release();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(device, ctx);
    ImGui::StyleColorsDark();
    return true;
}

void Overlay::syncToTarget() {
    if (!targetHwnd) return;
    RECT r{};
    GetClientRect(targetHwnd, &r);
    POINT tl{ r.left, r.top };
    ClientToScreen(targetHwnd, &tl);
    SetWindowPos(hwnd, HWND_TOPMOST, tl.x, tl.y, r.right, r.bottom, SWP_NOACTIVATE);
}

void Overlay::beginFrame() {
    syncToTarget();
    MSG msg{};
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
        if (msg.message == WM_QUIT) shouldClose = true;
    }
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    // fullscreen invisible draw surface
    ImGui::SetNextWindowPos({0,0});
    ImGui::SetNextWindowSize({(float)W,(float)H});
    ImGui::SetNextWindowBgAlpha(0.f);
    ImGui::Begin("##draw", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_NoSavedSettings);
}

void Overlay::endFrame() {
    ImGui::End();
    ImGui::Render();
    constexpr float clear[4]{0,0,0,0};
    ctx->OMSetRenderTargets(1, &rtv, nullptr);
    ctx->ClearRenderTargetView(rtv, clear);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    swap->Present(0, 0); // vsync off for max throughput
}

void Overlay::shutdown() {
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (rtv)   rtv->Release();
    if (swap)  swap->Release();
    if (ctx)   ctx->Release();
    if (device) device->Release();
    if (hwnd)  DestroyWindow(hwnd);
}

bool Overlay::alive() const {
    return !shouldClose && IsWindow(targetHwnd);
}