// cs2_external | main.cpp | thread model: render main, entity update worker
#define NOMINMAX
#include <Windows.h>
#include <mutex>
#include <thread>
#include <atomic>
#include <vector>
#include <chrono>
#include <cstdio>
#include "mem.h"
#include "entity.h"
#include "esp.h"
#include "aimbot.h"
#include "overlay.h"
#include "menu.h"
#include "cs2_math.h"
#include <imgui.h>

static std::atomic<bool>       g_running{ true };
static std::vector<Entity>     g_ents;
static Entity                  g_local{};
static Mat4                    g_vm{};
static std::mutex              g_entMtx;

void entityThread(const Memory* mem) {
    using namespace std::chrono_literals;
    while (g_running.load()) {
        uintptr_t listBase  = mem->read<uintptr_t>(mem->base + offsets::dwEntityList);
        uintptr_t localPawn = mem->read<uintptr_t>(mem->base + offsets::dwLocalPlayerPawn);

        Mat4 vm{};
        mem->readBuf(mem->base + offsets::dwViewMatrix, &vm, sizeof(vm));

        Entity local{};
        if (localPawn) {
            local.health = mem->read<int>  (localPawn + offsets::m_iHealth);
            local.team   = mem->read<int>  (localPawn + offsets::m_iTeamNum);
            local.origin = mem->read<Vec3> (localPawn + offsets::m_vOldOrigin);
            local.pawn   = localPawn;
            local.valid  = local.health > 0;
        }

        std::vector<Entity> ents;
        ents.reserve(64);
        for (int i = 1; i < 64; ++i) {
            uintptr_t entry = mem->read<uintptr_t>(listBase + 0x8 * (i >> 9) + 0x10);
            if (!entry) continue;
            Entity e = Entity::from(*mem, entry, i);
            if (e.valid) ents.push_back(e);
        }

        {
            std::lock_guard<std::mutex> lk(g_entMtx);
            g_ents  = std::move(ents);
            g_local = local;
            g_vm    = vm;
        }

        if (local.valid)
            aimbot::update(*mem, localPawn, local.team, g_ents);

        std::this_thread::sleep_for(1ms);
    }
}

int main() {
    Memory* mem = nullptr;
    try {
        mem = new Memory(L"cs2.exe");
    } catch (const std::exception& e) {
        std::fprintf(stderr, "mem: %s\n", e.what());
        return 1;
    }

    Overlay ov;
    if (!ov.init(L"Counter-Strike 2")) {
        std::fprintf(stderr, "overlay: init failed\n");
        delete mem; return 1;
    }

    std::thread eThread(entityThread, mem);
    bool menuOpen = false;

    while (ov.alive() && g_running.load()) {
        ov.beginFrame();

        if (GetAsyncKeyState(VK_INSERT) & 1) menuOpen = !menuOpen;
        menu::draw(menuOpen);

        std::vector<Entity> snap;
        Entity localSnap;
        Mat4 vmSnap;
        {
            std::lock_guard<std::mutex> lk(g_entMtx);
            snap      = g_ents;
            localSnap = g_local;
            vmSnap    = g_vm;
        }

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        esp::draw(dl, snap, localSnap, vmSnap,
                  static_cast<float>(ov.W),
                  static_cast<float>(ov.H));

        ov.endFrame();
    }

    g_running.store(false);
    eThread.join();
    ov.shutdown();
    delete mem;
    return 0;
}
