// cs2_external | aimbot.cpp | smooth FOV-gated bone aimbot, mouse_event output
#define NOMINMAX
#include <Windows.h>
#include "aimbot.h"
#include "cs2_math.h"
#include "menu.h"
#include "entity.h"
#include "mem.h"
#include <limits>
#include <cmath>

static Vec2 getViewAngles(const Memory& mem, uintptr_t localPawn) {
    constexpr uintptr_t m_angEyeAngles = 0x1510;
    return mem.read<Vec2>(localPawn + m_angEyeAngles);
}

static void moveMouse(long dx, long dy) {
    if (dx == 0 && dy == 0) return;
    INPUT in{};
    in.type       = INPUT_MOUSE;
    in.mi.dwFlags = MOUSEEVENTF_MOVE;
    in.mi.dx      = dx;
    in.mi.dy      = dy;
    SendInput(1, &in, sizeof(INPUT));
}

void aimbot::update(const Memory& mem,
                    uintptr_t localPawn, int localTeam,
                    const std::vector<Entity>& ents) {
    if (!g_cfg.aimbotEnabled.load()) return;
    if (g_cfg.aimbotOnKey.load() &&
        !(GetAsyncKeyState(g_cfg.aimbotKey.load()) & 0x8000)) return;

    Vec2  curAng  = getViewAngles(mem, localPawn);
    float fovGate = g_cfg.aimbotFOV.load();
    float smooth  = g_cfg.aimbotSmooth.load();
    int   bone    = g_cfg.aimbotBone.load();

    const Entity* best    = nullptr;
    float bestFov = (std::numeric_limits<float>::max)();

    for (const auto& e : ents) {
        if (!e.valid) continue;
        if (g_cfg.aimbotTeamCheck.load() && e.team == localTeam) continue;
        if (g_cfg.aimbotFlashCheck.load() && e.flashAlpha > 1.f) continue;

        Vec3 bonePos = Entity::readBone(mem, e.pawn, bone);
        Vec2 needed  = math::calcAngle(e.origin, bonePos);
        float fov    = math::fovDelta(curAng, needed);
        if (fov < fovGate && fov < bestFov) {
            bestFov = fov;
            best    = &e;
        }
    }

    if (!best) return;

    Vec3 target    = Entity::readBone(mem, best->pawn, bone);
    Vec2 targetAng = math::calcAngle(best->origin, target);
    Vec2 smoothed  = math::smoothAngle(curAng, targetAng, smooth);

    constexpr float DEG_TO_PIX = 10.f; // FILL: tune per sensitivity
    long dx = static_cast<long>((smoothed.y - curAng.y) * DEG_TO_PIX);
    long dy = static_cast<long>((smoothed.x - curAng.x) * DEG_TO_PIX);
    moveMouse(dx, dy);
}
