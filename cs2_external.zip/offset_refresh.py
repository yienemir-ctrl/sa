# cs2_external | offset_refresh.py
# drops into project root — run once, keeps offsets.h current forever
# source: github.com/a2x/cs2-dumper (JSON schema, updates after each patch)
# built by 45ms — https://dsc.gg/pyre-lua

import urllib.request
import json
import time
import hashlib
import os
from datetime import datetime, timezone

DUMP_URLS = {
    "client": "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/client.dll.json",
    "offsets": "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/offsets.json",
}

OUT_PATH   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", "offsets.h")
INTERVAL_S = 60  # re-check every 60s — tighten to 10 on patch day

OFFSET_MAP = {
    ("offsets", ("client.dll", "dwEntityList")):             "dwEntityList",
    ("offsets", ("client.dll", "dwLocalPlayerPawn")):        "dwLocalPlayerPawn",
    ("offsets", ("client.dll", "dwViewMatrix")):             "dwViewMatrix",
    ("offsets", ("client.dll", "dwLocalPlayerController")): "dwLocalPlayerController",

    ("client", ("C_BaseEntity",        "m_iHealth")):        "m_iHealth",
    ("client", ("C_BaseEntity",        "m_iTeamNum")):       "m_iTeamNum",
    ("client", ("C_BasePlayerPawn",    "m_vOldOrigin")):     "m_vOldOrigin",
    ("client", ("C_BaseEntity",        "m_pGameSceneNode")): "m_pGameSceneNode",
    ("client", ("CSkeletonInstance",   "m_modelState")):     "m_modelState",
    ("client", ("C_BaseEntity",        "m_bDormant")):       "m_bDormant",
    ("client", ("CEntityInstance",     "m_iIDEntIndex")):    "m_iIDEntIndex",
    ("client", ("CCSPlayerController", "m_iszPlayerName")):  "m_iszPlayerName",
    ("client", ("C_CSPlayerPawnBase",  "m_flFlashDuration")):"m_flFlashDuration",
    ("client", ("C_CSPlayerPawnBase",  "m_pClippingWeapon")):"m_pClippingWeapon",
    ("client", ("C_BasePlayerWeapon",  "m_iClip1")):         "m_iClip1",
}

STATIC = {
    "m_nBoneCount":  0x1E8,
    "m_pBoneArray":  0x1F0,
    "m_angEyeAngles":0x1510,
}

BONES = {
    "head":  6,
    "neck":  5,
    "chest": 4,
    "pelvis":0,
}


def fetch(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "cs2-offset-refresh/1.0"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode())


def resolve(data: dict, path: tuple):
    node = data
    for k in path:
        if isinstance(node, dict):
            node = node.get(k)
        else:
            return None
        if node is None:
            return None
    if isinstance(node, dict):
        return node.get("offset")
    if isinstance(node, int):
        return node
    return None


def build_header(resolved: dict, ts: str) -> str:
    def hexf(v): return f"0x{v:X}"

    lines = [
        "// cs2_external | offsets.h",
        f"// auto-generated {ts} UTC — do not hand-edit",
        "// built by 45ms — https://dsc.gg/pyre-lua",
        "#pragma once",
        "#include <cstdint>",
        "",
        "namespace offsets {",
        "    // ── auto-dumped ─────────────────────────────────────────",
    ]

    dw_keys = [k for k in resolved if k.startswith("dw")]
    m_keys  = [k for k in resolved if k.startswith("m_")]

    for k in dw_keys:
        pad = max(1, 46 - len(k))
        lines.append(f"    inline constexpr uintptr_t {k}{' '*pad}= {hexf(resolved[k])};")

    lines.append("")

    for k in m_keys:
        pad = max(1, 46 - len(k))
        lines.append(f"    inline constexpr uintptr_t {k}{' '*pad}= {hexf(resolved[k])};")

    lines += [
        "",
        "    // ── static (verify on ABI break) ────────────────────────",
    ]
    for k, v in STATIC.items():
        pad = max(1, 46 - len(k))
        lines.append(f"    inline constexpr uintptr_t {k}{' '*pad}= {hexf(v)};")

    lines += ["} // namespace offsets", "", "namespace bones {"]
    for k, v in BONES.items():
        pad = max(1, 46 - len(k))
        lines.append(f"    inline constexpr int {k}{' '*pad}= {v};")
    lines.append("} // namespace bones")
    lines.append("")
    return "\n".join(lines)


def file_hash(path: str) -> str:
    if not os.path.exists(path):
        return ""
    return hashlib.md5(open(path, "rb").read()).hexdigest()


def refresh() -> bool:
    try:
        raw = {k: fetch(u) for k, u in DUMP_URLS.items()}
    except Exception as e:
        print(f"  [fetch error] {e}")
        return False

    resolved = {}
    missing  = []

    for (src, path), cpp_name in OFFSET_MAP.items():
        if src == "offsets":
            val = resolve(raw[src], path)
        else:
            cls, member = path
            val = resolve(raw[src], ("classes", cls, "fields", member))

        if val is None:
            missing.append(cpp_name)
        else:
            resolved[cpp_name] = val

    if missing:
        print(f"  [warn] could not resolve: {', '.join(missing)}")
    if not resolved:
        print("  [error] zero offsets resolved — skipping write")
        return False

    ts     = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    header = build_header(resolved, ts)

    old_hash = file_hash(OUT_PATH)
    new_hash = hashlib.md5(header.encode()).hexdigest()

    if old_hash == new_hash:
        print(f"  [{ts}] no change")
        return False

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        f.write(header)
    print(f"  [{ts}] offsets.h written — {len(resolved)} offsets resolved")
    if missing:
        print(f"           FILL manually: {', '.join(missing)}")
    return True


def main():
    print("cs2 offset refresher — absolute 45ms")
    print(f"output  : {OUT_PATH}")
    print(f"interval: {INTERVAL_S}s  |  Ctrl+C to stop\n")
    while True:
        refresh()
        try:
            time.sleep(INTERVAL_S)
        except KeyboardInterrupt:
            print("\nbench clear.")
            break


if __name__ == "__main__":
    main()